package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class OrderController {
	@Autowired
	KafkaSender kafkaSender;
	
	@RequestMapping("/")
	public String Order() {
		return "Order";
		
	}
	
	  @RequestMapping(value="/producer",method=RequestMethod.POST)
		
		public String producer(  String item_name,String subtotal) {
		  Order order=new Order();
		 String item=order.getItem_name();
		 System.out.println(item);
			kafkaSender.send(item,subtotal);
			return "Order";

			
		}


}
