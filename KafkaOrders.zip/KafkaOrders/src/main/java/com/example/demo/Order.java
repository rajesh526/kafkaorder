package com.example.demo;

public class Order {
	private String item_name;
	private int subtotal;
	
	public Order() {}
	public Order(String item_name,int sunbtotal) {
		this.item_name=item_name;
		this.subtotal=sunbtotal;
	}
	public String getItem_name() {
		return item_name;
	}
	public void setItem_name(String item_name) {
		this.item_name = item_name;
	}
	public int getSubtotal() {
		return subtotal;
	}
	public void setSubtotal(int subtotal) {
		this.subtotal = subtotal;
	}

}
